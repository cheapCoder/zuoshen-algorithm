package class01;

public class Code06_BSAwesome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
